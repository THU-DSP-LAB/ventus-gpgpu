#include "BASE.h"
void BASE::INIT_INS(int warp_id)
{
    WARPS[warp_id].ireg[0] = I_TYPE(VBEQ_, 3, 0, 1);
    // if path
    WARPS[warp_id].ireg[1] = I_TYPE(ADDI_, 2, 0, 1219);
    WARPS[warp_id].ireg[2] = I_TYPE(VADD_VX_, 10, 5, 2);
    WARPS[warp_id].ireg[3] = I_TYPE(JOIN_, 3, -1, -1);
    // else path
    WARPS[warp_id].ireg[4] = I_TYPE(ADDI_, 3, 0, 4444);
    WARPS[warp_id].ireg[5] = I_TYPE(VADD_VX_, 11, 5, 3);
    WARPS[warp_id].ireg[6] = I_TYPE(JOIN_, 0, -1, -1);
    // 汇合点
    WARPS[warp_id].ireg[7] = I_TYPE(ADDI_, 4, 0, 99999);
    WARPS[warp_id].ireg[8] = I_TYPE(VADD_VX_, 12, 5, 4);

    // WARPS[warp_id].ireg[0] = I_TYPE(BEQ_, 80, 20, 21);
}
