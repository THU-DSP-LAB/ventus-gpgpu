# 导入必要的库
import re

# 定义解析规则的正则表达式
pattern = r"^(\w+)\s*->\s*List\(([\w\s\.\,]+)\)"

# 打开要读取的文件
with open("init_decodetable.txt", "r") as f:
    # 消除每行开头空行
    lines = [line.strip() for line in f if line.strip()]
    # 创建输出文件
    with open("init_decodetable.cpp", "w") as out_file:
        # 逐行读取输入文件内容
        out_file.write(
            '#include "BASE.h"\nvoid BASE::INIT_DECODETABLE(){\ndecode_table = {\n'
        )
        for line in lines:
            # 使用正则表达式匹配当前行的内容
            match = re.match(pattern, line)
            if match:
                # 获取指令名称
                opcode = match.group(1)
                print("opcode =", opcode)
                # 将指令名称中的“->”替换为下划线
                opcode = opcode.replace("->", "_")
                # 获取指令参数列表
                params = match.group(2).split(",")
                # 删除每一项的所有空格
                for i in range(len(params)):
                    params[i] = params[i].strip().replace(" ", "")
                # 对每个参数进行处理
                processed_params = []
                for param in params:
                    # 如果参数为N或Y，则将其转换为0或1
                    if param == "N":
                        processed_params.append("0")
                    elif param == "Y":
                        processed_params.append("1")
                    else:
                        # 如果参数包含“.”，则将“.”转换为下划线
                        if "." in param:
                            param = param.replace(".", "_")
                        # 在参数前添加“DecodeParams::”
                        param = "DecodeParams::" + param
                        processed_params.append(param)
                # 将处理后的参数列表转换为C++代码形式
                code_params = ", ".join(processed_params)
                # 将结果写入输出文件
                out_file.write("{{{0}_, {{{1}}}}}, \n".format(opcode, code_params))
        out_file.write("};\n}")
