#include <iostream>
#include <bit>

using namespace std;

int main()
{
    int n = -30043099;
    float f1 = std::bit_cast<float>(n);
    float f2 = static_cast<float>(n);
    float f3 = *(float *)&n;
    unsigned un = static_cast<unsigned>(n);
    std::cout << n << ", un=" << un << ", f1=" << f1 << ", f2=" << f2 << ", f3=" << f3 << std::endl;
    int m = -1;
    unsigned int um = (unsigned int)m;
    float fm = (float)m;
    float fum = (float)(unsigned int)m;
    cout << "um=" << um << ", fm=" << fm << ", fum=" << fum << endl;
    float a1 = 465.67365;
    float a2 = -42656.85673;
    float b1 = (std::bit_cast<std::uint32_t>(a1) & 0x7fffffff) |
               (std::bit_cast<std::uint32_t>(a2) & 0x80000000);
    float b2 = std::bit_cast<float>(
        (std::bit_cast<std::uint32_t>(a1) & 0x7fffffff) |
        (std::bit_cast<std::uint32_t>(a2) & 0x80000000));
    cout << "b1=" << b1 << ", b2=" << b2 << endl;
    int i1 = 0x80000000;
    unsigned i2 = 0x80000000u;
    cout << "i1=" << i1 << ", i2=" << i2 << endl;
    return 0;
}